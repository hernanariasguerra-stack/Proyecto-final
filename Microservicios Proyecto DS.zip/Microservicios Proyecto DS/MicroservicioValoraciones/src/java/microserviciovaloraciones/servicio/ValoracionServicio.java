/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package microserviciovaloraciones.servicio;

import microserviciovaloraciones.dto.ValoracionDTO;
import microserviciovaloraciones.fabrica.FabricaDaoValoracion;
import microserviciovaloraciones.persistencia.ValoracionDAO;
import microserviciovaloraciones.modelo.Valoracion;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Optional;
import org.json.JSONObject;

/**
 *
 * @author isaac
 */
public class ValoracionServicio {

    private final ValoracionDAO dao;

    public ValoracionServicio(String tipoBD) {
        this.dao = FabricaDaoValoracion.crear(tipoBD);
    }

    public ValoracionServicio() {
        this.dao = FabricaDaoValoracion.crear("MONGO");
    }

    public boolean crearValoracion(ValoracionDTO dto) throws Exception {
        if (!validarUsuario(dto.getIdUsuario())) {
            throw new Exception("Usuario no válido");
        }
        if (!validarOportunidad(dto.getIdOportunidad())) {
            throw new Exception("Oportunidad no válida");
        }
        Valoracion v = new Valoracion();
        v.setIdUsuario(dto.getIdUsuario());
        v.setIdOportunidad(dto.getIdOportunidad());
        v.setComentario(dto.getComentario());
        v.setCalificacion(dto.getCalificacion());
        return dao.insertar(v);
    }

    public Optional<Valoracion> obtenerPorId(Integer id) throws Exception {
        return dao.consultarPorId(id);
    }

    public Optional<Valoracion> obtenerPorId(String idMongo) throws Exception {
        return dao.consultarPorId(idMongo);
    }

    public List<Valoracion> listarPorOportunidad(Integer idOportunidad) throws Exception {
        return dao.listarPorOportunidad(idOportunidad);
    }

    public List<Valoracion> listarTodas() throws Exception {
        return dao.listarTodos();
    }

    public boolean actualizar(Valoracion v) throws Exception {
        return dao.actualizar(v);
    }

    public boolean eliminar(Integer id) throws Exception {
        return dao.eliminar(id);
    }

    public boolean eliminar(String mongoId) throws Exception {
        return dao.eliminar(mongoId);
    }

    private boolean validarUsuario(Integer idUsuario) {
        try {
            String urlStr = "http://localhost:8080/MicroservicioUsuarios/usuarioApi?action=existsById&id=" + idUsuario;
            HttpURLConnection con = (HttpURLConnection) new URL(urlStr).openConnection();
            con.setRequestMethod("GET");
            con.setConnectTimeout(3000);
            con.setReadTimeout(3000);
            int status = con.getResponseCode();
            if (status != 200) {
                return false;
            }
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = in.readLine()) != null) {
                sb.append(line);
            }
            in.close();
            JSONObject jo = new JSONObject(sb.toString());
            return jo.optBoolean("exists", false);
        } catch (Exception e) {
            return false;
        }
    }

    private boolean validarOportunidad(Integer idOportunidad) {
        try {
            String urlStr = "http://localhost:8081/MicroservicioOportunidades/oportunidadApi?action=existsById&id=" + idOportunidad;
            HttpURLConnection con = (HttpURLConnection) new URL(urlStr).openConnection();
            con.setRequestMethod("GET");
            con.setConnectTimeout(3000);
            con.setReadTimeout(3000);
            int status = con.getResponseCode();
            if (status != 200) {
                return false;
            }
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = in.readLine()) != null) {
                sb.append(line);
            }
            in.close();
            JSONObject jo = new JSONObject(sb.toString());
            return jo.optBoolean("exists", false);
        } catch (Exception e) {
            return false;
        }
    }
}
