/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package microserviciovaloraciones.presentacion;

import microserviciovaloraciones.dto.ValoracionDTO;
import microserviciovaloraciones.servicio.ValoracionServicio;
import microserviciovaloraciones.modelo.Valoracion;
import java.io.IOException;
import java.util.List;
import java.util.Optional;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author isaac
 */
@WebServlet(name = "ValoracionControl", urlPatterns = {"/valoracion"})
public class ValoracionControl extends HttpServlet {

    private ValoracionServicio servicio;

    @Override
    public void init() throws ServletException {
        super.init();
        servicio = new ValoracionServicio("MONGO");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        try {
            switch (action.toLowerCase()) {
                case "list":
                    List<Valoracion> lista = servicio.listarTodas();
                    request.setAttribute("lista", lista);
                    request.getRequestDispatcher("listar.jsp").forward(request, response);
                    return;
                case "createform":
                    request.getRequestDispatcher("crear.jsp").forward(request, response);
                    return;
                case "detail":
                    String idStr = request.getParameter("id");
                    Optional<Valoracion> vDetail = parseAndObtener(idStr);
                    if (vDetail.isPresent()) {
                        request.setAttribute("valoracion", vDetail.get());
                        request.getRequestDispatcher("detalle.jsp").forward(request, response);
                    } else {
                        response.sendRedirect("listar.jsp?error=Valoración+no+encontrada");
                    }
                    return;
                case "editform":
                    String idEdit = request.getParameter("id");
                    Optional<Valoracion> vEdit = parseAndObtener(idEdit);
                    if (vEdit.isPresent()) {
                        request.setAttribute("valoracion", vEdit.get());
                        request.getRequestDispatcher("editar.jsp").forward(request, response);
                    } else {
                        response.sendRedirect("valoracion?action=list&error=Valoración+no+encontrada");
                    }
                    return;
                case "delete":
                    String idDel = request.getParameter("id");
                    boolean resultado = false;
                    if (idDel != null) {
                        if (idDel.matches("^[a-fA-F0-9]{24}$")) {
                            resultado = servicio.eliminar(idDel);
                        } else {
                            resultado = servicio.eliminar(Integer.parseInt(idDel));
                        }
                    }
                    if (resultado) {
                        response.sendRedirect("valoracion?action=list&msg=Valoración+eliminada");
                    } else {
                        response.sendRedirect("valoracion?action=list&error=No+se+elimino");
                    }
                    return;
                case "byoportunidad":
                    Integer idO = Integer.parseInt(request.getParameter("idOportunidad"));
                    List<Valoracion> listaO = servicio.listarPorOportunidad(idO);
                    request.setAttribute("lista", listaO);
                    request.getRequestDispatcher("listar.jsp").forward(request, response);
                    return;
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
        response.sendRedirect("index.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        try {
            switch (action.toLowerCase()) {
                case "create":
                    try {
                        Integer idUsuario = Integer.parseInt(request.getParameter("idUsuario"));
                        Integer idOportunidad = Integer.parseInt(request.getParameter("idOportunidad"));
                        String comentario = request.getParameter("comentario");
                        Integer calificacion = Integer.parseInt(request.getParameter("calificacion"));

                        System.out.println("Parametros recibidos:");
                        System.out.println("idUsuario=" + idUsuario);
                        System.out.println("idOportunidad=" + idOportunidad);
                        System.out.println("comentario=" + comentario);
                        System.out.println("calificacion=" + calificacion);

                        ValoracionDTO dto = new ValoracionDTO(idUsuario, idOportunidad, comentario, calificacion);

                        boolean ok = servicio.crearValoracion(dto);
                        System.out.println("Resultado creación: " + ok);

                        if (ok) {
                            response.sendRedirect("crear.jsp?msg=Valoración+creada+exitosamente");
                        } else {
                            response.sendRedirect("crear.jsp?error=No+se+pudo+crear+valoración");
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        response.sendRedirect("error.jsp?detalle=" + e.getMessage());
                    }
                    return;
                case "update":
                    String idStr = request.getParameter("id");
                    Optional<Valoracion> vOpt = parseAndObtener(idStr);
                    if (vOpt.isPresent()) {
                        Valoracion v = vOpt.get();
                        v.setComentario(request.getParameter("comentario"));
                        v.setCalificacion(Integer.parseInt(request.getParameter("calificacion")));
                        if (servicio.actualizar(v)) {
                            response.sendRedirect("valoracion?action=list&msg=Valoración+actualizada");
                        } else {
                            response.sendRedirect("valoracion?action=list&error=No+se+actualizó");
                        }
                    } else {
                        response.sendRedirect("valoracion?action=list&error=Valoración+no+encontrada");
                    }
                    return;
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }

    private Optional<Valoracion> parseAndObtener(String idStr) throws Exception {
        if (idStr == null) {
            return Optional.empty();
        }
        if (idStr.matches("^[a-fA-F0-9]{24}$")) {
            return servicio.obtenerPorId(idStr);
        } else {
            try {
                Integer id = Integer.parseInt(idStr);
                return servicio.obtenerPorId(id);
            } catch (NumberFormatException e) {
                return Optional.empty();
            }
        }
    }
}
