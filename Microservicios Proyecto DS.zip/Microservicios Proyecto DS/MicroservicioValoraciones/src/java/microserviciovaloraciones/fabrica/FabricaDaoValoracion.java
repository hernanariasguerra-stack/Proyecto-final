/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package microserviciovaloraciones.fabrica;

import microserviciovaloraciones.persistencia.ValoracionDAO;
import microserviciovaloraciones.persistencia.ValoracionDaoMongo;
import microserviciovaloraciones.persistencia.ValoracionDaoPostgre;

/**
 *
 * @author isaac
 */
public class FabricaDaoValoracion {

    public static ValoracionDAO crear(String tipo) {
        if ("MONGO".equalsIgnoreCase(tipo)) {
            return new ValoracionDaoMongo();
        } else if ("POSTGRE".equalsIgnoreCase(tipo)) {
            return new ValoracionDaoPostgre();
        }
        return new ValoracionDaoMongo();
    }
}

