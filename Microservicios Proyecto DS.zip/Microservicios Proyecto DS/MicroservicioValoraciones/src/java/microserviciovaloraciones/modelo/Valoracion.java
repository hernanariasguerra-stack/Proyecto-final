/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package microserviciovaloraciones.modelo;

import org.bson.types.ObjectId;

/**
 *
 * @author isaac
 */
public class Valoracion implements Cloneable {

    private String mongoId;
    private Integer id;
    private Integer idUsuario;
    private Integer idOportunidad;
    private String comentario;
    private Integer calificacion;
    private java.sql.Timestamp createdAt;
    private ObjectId idMongo;

    public Valoracion() {
    }

    public Valoracion(String mongoId, Integer id, Integer idUsuario, Integer idOportunidad, String comentario, Integer calificacion, java.sql.Timestamp createdAt) {
        this.mongoId = mongoId;
        this.id = id;
        this.idUsuario = idUsuario;
        this.idOportunidad = idOportunidad;
        this.comentario = comentario;
        this.calificacion = calificacion;
        this.createdAt = createdAt;
    }

    public String getMongoId() {
        return mongoId;
    }

    public void setMongoId(String mongoId) {
        this.mongoId = mongoId;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(Integer idUsuario) {
        this.idUsuario = idUsuario;
    }

    public Integer getIdOportunidad() {
        return idOportunidad;
    }

    public void setIdOportunidad(Integer idOportunidad) {
        this.idOportunidad = idOportunidad;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    public Integer getCalificacion() {
        return calificacion;
    }

    public void setCalificacion(Integer calificacion) {
        this.calificacion = calificacion;
    }

    public java.sql.Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(java.sql.Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public ObjectId getIdMongo() {
        return idMongo;
    }

    public void setIdMongo(ObjectId idMongo) {
        this.idMongo = idMongo;
    }

    @Override
    public Valoracion clone() {
        try {
            return (Valoracion) super.clone();
        } catch (CloneNotSupportedException e) {
            return new Valoracion(mongoId, id, idUsuario, idOportunidad, comentario, calificacion, createdAt);
        }
    }
}
