/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package microserviciovaloraciones.persistencia;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import static com.mongodb.client.model.Filters.eq;
import com.mongodb.client.result.DeleteResult;
import com.mongodb.client.result.UpdateResult;
import microserviciovaloraciones.modelo.Valoracion;
import microserviciovaloraciones.singleton.ConexionMongo;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.bson.Document;
import org.bson.types.ObjectId;

/**
 *
 * @author isaac
 */
public class ValoracionDaoMongo implements ValoracionDAO {

    private final MongoCollection<Document> collection;

    public ValoracionDaoMongo() {
        MongoDatabase db = ConexionMongo.getInstance().getDatabase();
        this.collection = db.getCollection("valoraciones");
    }

    @Override
    public boolean insertar(Valoracion valoracion) throws Exception {
        ObjectId mongoId = new ObjectId();

        Document doc = new Document("_id", mongoId)
                .append("idUsuario", valoracion.getIdUsuario())
                .append("idOportunidad", valoracion.getIdOportunidad())
                .append("comentario", valoracion.getComentario())
                .append("calificacion", valoracion.getCalificacion());

        collection.insertOne(doc);

        valoracion.setMongoId(mongoId.toHexString());
        valoracion.setId(mongoId.hashCode());

        return true;
    }

    @Override
    public Optional<Valoracion> consultarPorId(Integer id) throws Exception {
        return Optional.empty();
    }

    @Override
    public Optional<Valoracion> consultarPorId(String mongoId) throws Exception {
        ObjectId oid = new ObjectId(mongoId);
        Document doc = collection.find(eq("_id", oid)).first();
        if (doc == null) {
            return Optional.empty();
        }
        return Optional.of(documentToValoracion(doc));
    }

    @Override
    public boolean eliminar(Integer id) throws Exception {
        return false;
    }

    @Override
    public boolean eliminar(String mongoId) throws Exception {
        ObjectId oid = new ObjectId(mongoId);
        DeleteResult result = collection.deleteOne(eq("_id", oid));
        return result.getDeletedCount() > 0;
    }

    @Override
    public boolean actualizar(Valoracion v) throws Exception {
        ObjectId oid = new ObjectId(v.getMongoId());

        UpdateResult result = collection.updateOne(
                eq("_id", oid),
                new Document("$set",
                        new Document("comentario", v.getComentario())
                        .append("calificacion", v.getCalificacion())
                )
        );
        return result.getModifiedCount() > 0;
    }

    @Override
    public List<Valoracion> listarPorOportunidad(Integer idOportunidad) throws Exception {
        List<Valoracion> lista = new ArrayList<>();
        for (Document doc : collection.find(eq("idOportunidad", idOportunidad))) {
            lista.add(documentToValoracion(doc));
        }
        return lista;
    }

    @Override
    public List<Valoracion> listarTodos() throws Exception {
        List<Valoracion> lista = new ArrayList<>();
        for (Document doc : collection.find()) {
            lista.add(documentToValoracion(doc));
        }
        return lista;
    }

    private Valoracion documentToValoracion(Document doc) {
        Valoracion v = new Valoracion();
        ObjectId oid = doc.getObjectId("_id");

        v.setMongoId(oid.toHexString());
        v.setId(oid.hashCode());
        v.setIdUsuario(doc.getInteger("idUsuario"));
        v.setIdOportunidad(doc.getInteger("idOportunidad"));
        v.setComentario(doc.getString("comentario"));
        v.setCalificacion(doc.getInteger("calificacion"));

        return v;
    }
}
