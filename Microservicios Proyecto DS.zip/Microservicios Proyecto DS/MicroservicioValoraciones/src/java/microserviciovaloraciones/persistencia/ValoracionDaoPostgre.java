/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package microserviciovaloraciones.persistencia;

import microserviciovaloraciones.modelo.Valoracion;
import microserviciovaloraciones.singleton.ConexionPostgre;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author isaac
 */
public class ValoracionDaoPostgre implements ValoracionDAO {

    private final ConexionPostgre conexion = ConexionPostgre.getInstance();

    @Override
    public boolean insertar(Valoracion v) throws Exception {
        String sql = "INSERT INTO valoraciones_postgres(id_usuario, id_oportunidad, comentario, calificacion, created_at) VALUES(?,?,?,?,?)";
        try (Connection conn = conexion.getConnection(); 
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setObject(1, v.getIdUsuario());
            ps.setObject(2, v.getIdOportunidad());
            ps.setString(3, v.getComentario());
            ps.setObject(4, v.getCalificacion());
            ps.setTimestamp(5, new Timestamp(System.currentTimeMillis()));

            int r = ps.executeUpdate();
            if (r > 0) {
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        v.setId(rs.getInt(1));
                    }
                }
                return true;
            }
            return false;
        }
    }

    @Override
    public Optional<Valoracion> consultarPorId(Integer id) throws Exception {
        String sql = "SELECT id, id_usuario, id_oportunidad, comentario, calificacion, created_at FROM valoraciones_postgres WHERE id = ?";
        try (Connection conn = conexion.getConnection(); 
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Valoracion v = new Valoracion();
                    v.setId(rs.getInt("id"));
                    v.setIdUsuario(rs.getInt("id_usuario"));
                    v.setIdOportunidad(rs.getInt("id_oportunidad"));
                    v.setComentario(rs.getString("comentario"));
                    v.setCalificacion(rs.getInt("calificacion"));
                    v.setCreatedAt(rs.getTimestamp("created_at"));
                    return Optional.of(v);
                }
                return Optional.empty();
            }
        }
    }

    @Override
    public Optional<Valoracion> consultarPorId(String mongoId) throws Exception {
        return Optional.empty();
    }

    @Override
    public boolean actualizar(Valoracion v) throws Exception {
        String sql = "UPDATE valoraciones_postgres SET comentario=?, calificacion=? WHERE id=?";
        try (Connection conn = conexion.getConnection(); 
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, v.getComentario());
            ps.setObject(2, v.getCalificacion());
            ps.setObject(3, v.getId());

            return ps.executeUpdate() > 0;
        }
    }

    @Override
    public boolean eliminar(Integer id) throws Exception {
        String sql = "DELETE FROM valoraciones_postgres WHERE id = ?";
        try (Connection conn = conexion.getConnection(); 
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    @Override
    public boolean eliminar(String mongoId) throws Exception {
        return false;
    }

    @Override
    public List<Valoracion> listarPorOportunidad(Integer idOportunidad) throws Exception {
        String sql = "SELECT id, id_usuario, id_oportunidad, comentario, calificacion, created_at FROM valoraciones_postgres WHERE id_oportunidad = ? ORDER BY created_at DESC";
        List<Valoracion> lista = new ArrayList<>();
        try (Connection conn = conexion.getConnection(); 
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setObject(1, idOportunidad);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Valoracion v = new Valoracion();
                    v.setId(rs.getInt("id"));
                    v.setIdUsuario(rs.getInt("id_usuario"));
                    v.setIdOportunidad(rs.getInt("id_oportunidad"));
                    v.setComentario(rs.getString("comentario"));
                    v.setCalificacion(rs.getInt("calificacion"));
                    v.setCreatedAt(rs.getTimestamp("created_at"));
                    lista.add(v);
                }
            }
        }
        return lista;
    }

    @Override
    public List<Valoracion> listarTodos() throws Exception {
        String sql = "SELECT id, id_usuario, id_oportunidad, comentario, calificacion, created_at FROM valoraciones_postgres ORDER BY created_at DESC";
        List<Valoracion> lista = new ArrayList<>();
        try (Connection conn = conexion.getConnection(); 
             PreparedStatement ps = conn.prepareStatement(sql); 
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Valoracion v = new Valoracion();
                v.setId(rs.getInt("id"));
                v.setIdUsuario(rs.getInt("id_usuario"));
                v.setIdOportunidad(rs.getInt("id_oportunidad"));
                v.setComentario(rs.getString("comentario"));
                v.setCalificacion(rs.getInt("calificacion"));
                v.setCreatedAt(rs.getTimestamp("created_at"));
                lista.add(v);
            }
        }
        return lista;
    }
}
