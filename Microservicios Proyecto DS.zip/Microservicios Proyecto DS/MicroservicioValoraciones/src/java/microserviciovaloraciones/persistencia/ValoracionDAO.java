/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package microserviciovaloraciones.persistencia;

import microserviciovaloraciones.modelo.Valoracion;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author isaac
 */
public interface ValoracionDAO {

    boolean insertar(Valoracion v) throws Exception;

    Optional<Valoracion> consultarPorId(Integer id) throws Exception;

    Optional<Valoracion> consultarPorId(String mongoId) throws Exception;

    boolean actualizar(Valoracion v) throws Exception;

    boolean eliminar(Integer id) throws Exception;

    boolean eliminar(String mongoId) throws Exception;

    List<Valoracion> listarPorOportunidad(Integer idOportunidad) throws Exception;

    List<Valoracion> listarTodos() throws Exception;
}
