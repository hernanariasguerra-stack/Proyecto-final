/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package microserviciovaloraciones.singleton;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;

/**
 *
 * @author isaac
 */
public class ConexionMongo {

    private static ConexionMongo instance;
    private MongoClient client;
    private MongoDatabase database;

    private ConexionMongo() {
        try {
            client = MongoClients.create("mongodb://localhost:27017");
            database = client.getDatabase("sgvc_db_microvaloracion");
            System.out.println("MongoDB conectado correctamente");
        } catch (Exception e) {
            System.out.println("Error al conectar a MongoDB: " + e.getMessage());
        }
    }

    public static synchronized ConexionMongo getInstance() {
        if (instance == null) {
            instance = new ConexionMongo();
        }
        return instance;
    }

    public MongoDatabase getDatabase() {
        return database;
    }
}
