/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package microserviciovaloraciones.dto;

/**
 *
 * @author isaac
 */
public class ValoracionDTO {

    private Integer idUsuario;
    private Integer idOportunidad;
    private String comentario;
    private Integer calificacion;

    public ValoracionDTO() {
    }

    public ValoracionDTO(Integer idUsuario, Integer idOportunidad, String comentario, Integer calificacion) {
        this.idUsuario = idUsuario;
        this.idOportunidad = idOportunidad;
        this.comentario = comentario;
        this.calificacion = calificacion;
    }

    public Integer getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(Integer idUsuario) {
        this.idUsuario = idUsuario;
    }

    public Integer getIdOportunidad() {
        return idOportunidad;
    }

    public void setIdOportunidad(Integer idOportunidad) {
        this.idOportunidad = idOportunidad;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    public Integer getCalificacion() {
        return calificacion;
    }

    public void setCalificacion(Integer calificacion) {
        this.calificacion = calificacion;
    }
}
