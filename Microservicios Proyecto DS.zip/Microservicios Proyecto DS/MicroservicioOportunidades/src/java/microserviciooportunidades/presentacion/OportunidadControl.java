/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package microserviciooportunidades.presentacion;

import microserviciooportunidades.dto.OportunidadDTO;
import microserviciooportunidades.servicio.OportunidadServicio;
import microserviciooportunidades.modelo.Oportunidad;
import java.io.IOException;
import java.util.List;
import java.util.Optional;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author isaac
 */
@WebServlet(name = "OportunidadControl", urlPatterns = {"/oportunidad"})
public class OportunidadControl extends HttpServlet {

    private OportunidadServicio servicio;

    @Override
    public void init() throws ServletException {
        super.init();
        servicio = new OportunidadServicio();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        try {
            if ("list".equalsIgnoreCase(action)) {
                List<Oportunidad> lista = servicio.listarTodas();
                request.setAttribute("lista", lista);
                request.getRequestDispatcher("listar.jsp").forward(request, response);
                return;

            } else if ("createForm".equalsIgnoreCase(action)) {
                request.getRequestDispatcher("crear.jsp").forward(request, response);
                return;

            } else if ("detail".equalsIgnoreCase(action)) {
                Integer id = Integer.parseInt(request.getParameter("id"));
                Optional<Oportunidad> o = servicio.obtenerPorId(id);
                if (o.isPresent()) {
                    request.setAttribute("oportunidad", o.get());
                    request.getRequestDispatcher("detalle.jsp").forward(request, response);
                    return;
                } else {
                    response.sendRedirect("listar.jsp?error=Oportunidad+no+existe");
                    return;
                }

            } else if ("editForm".equalsIgnoreCase(action)) {
                Integer id = Integer.parseInt(request.getParameter("id"));
                Optional<Oportunidad> o = servicio.obtenerPorId(id);
                if (o.isPresent()) {
                    request.setAttribute("oportunidad", o.get());
                    request.getRequestDispatcher("editar.jsp").forward(request, response);
                    return;
                } else {
                    response.sendRedirect("listar.jsp?error=No+se+encontró+la+oportunidad");
                    return;
                }

            } else if ("delete".equalsIgnoreCase(action)) {
                Integer id = Integer.parseInt(request.getParameter("id"));
                servicio.eliminar(id);
                response.sendRedirect("oportunidad?action=list&msg=Oportunidad+eliminada");
                return;
            }

        } catch (Exception e) {
            response.sendRedirect("listar.jsp?error=Error+interno");
            return;
        }

        response.sendRedirect("index.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        try {
            if ("create".equalsIgnoreCase(action)) {

                Integer idOrg = null;
                String idOrgStr = request.getParameter("idOrganizacion");
                if (idOrgStr != null && !idOrgStr.isEmpty()) {
                    idOrg = Integer.parseInt(idOrgStr);
                }

                String titulo = request.getParameter("titulo");
                String descripcion = request.getParameter("descripcion");
                String categoria = request.getParameter("categoria");
                String ubicacion = request.getParameter("ubicacion");
                String requisitos = request.getParameter("requisitos");

                OportunidadDTO dto = new OportunidadDTO(idOrg, titulo, descripcion, categoria, ubicacion, requisitos);

                servicio.crearOportunidad(dto);

                response.sendRedirect("oportunidad?action=list&msg=Oportunidad+creada");
                return;

            } else if ("update".equalsIgnoreCase(action)) {

                Integer id = Integer.parseInt(request.getParameter("id"));
                Oportunidad o = servicio.obtenerPorId(id).orElse(null);

                if (o != null) {
                    o.setTitulo(request.getParameter("titulo"));
                    o.setDescripcion(request.getParameter("descripcion"));
                    o.setCategoria(request.getParameter("categoria"));
                    o.setUbicacion(request.getParameter("ubicacion"));
                    o.setRequisitos(request.getParameter("requisitos"));
                    o.setEstado("true".equalsIgnoreCase(request.getParameter("estado")));
                    servicio.actualizar(o);

                    response.sendRedirect("oportunidad?action=list&msg=Oportunidad+actualizada");
                    return;
                } else {
                    response.sendRedirect("oportunidad?action=list&error=No+se+pudo+actualizar");
                    return;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("listar.jsp?error=Error+al+procesar");
            return;
        }

        response.sendRedirect("index.jsp");
    }
}
