/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package microserviciooportunidades.presentacion;

import microserviciooportunidades.servicio.OportunidadServicio;
import microserviciooportunidades.modelo.Oportunidad;
import java.io.IOException;
import java.util.Optional;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

/**
 *
 * @author isaac
 */
@WebServlet(name = "OportunidadApi", urlPatterns = {"/oportunidadApi"})
public class OportunidadApi extends HttpServlet {

    private OportunidadServicio servicio;

    @Override
    public void init() throws ServletException {
        super.init();
        servicio = new OportunidadServicio();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        response.setContentType("application/json");
        try {
            if ("existsById".equalsIgnoreCase(action)) {
                String idStr = request.getParameter("id");
                boolean exists = false;
                if (idStr != null && !idStr.isEmpty()) {
                    Integer id = Integer.parseInt(idStr);
                    Optional<Oportunidad> o = servicio.obtenerPorId(id);
                    exists = o.isPresent();
                }
                response.getWriter().write("{\"exists\":" + exists + "}");
                return;
            }
        } catch (Exception e) {
            response.getWriter().write("{\"exists\":false}");
            return;
        }
        response.getWriter().write("{\"exists\":false}");
    }
}
