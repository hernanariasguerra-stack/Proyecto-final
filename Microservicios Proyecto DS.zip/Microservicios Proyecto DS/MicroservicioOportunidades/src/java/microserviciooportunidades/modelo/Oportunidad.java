/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package microserviciooportunidades.modelo;

/**
 *
 * @author isaac
 */
public class Oportunidad implements Cloneable {

    private Integer id;
    private Integer idOrganizacion;
    private String titulo;
    private String descripcion;
    private String categoria;
    private String ubicacion;
    private String requisitos;
    private Boolean estado;

    public Oportunidad() {
    }

    public Oportunidad(Integer id, Integer idOrganizacion, String titulo, String descripcion, String categoria, String ubicacion, String requisitos, Boolean estado) {
        this.id = id;
        this.idOrganizacion = idOrganizacion;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.categoria = categoria;
        this.ubicacion = ubicacion;
        this.requisitos = requisitos;
        this.estado = estado;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getIdOrganizacion() {
        return idOrganizacion;
    }

    public void setIdOrganizacion(Integer idOrganizacion) {
        this.idOrganizacion = idOrganizacion;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public String getRequisitos() {
        return requisitos;
    }

    public void setRequisitos(String requisitos) {
        this.requisitos = requisitos;
    }

    public Boolean getEstado() {
        return estado;
    }

    public void setEstado(Boolean estado) {
        this.estado = estado;
    }

    @Override
    public Oportunidad clone() {
        try {
            return (Oportunidad) super.clone();
        } catch (CloneNotSupportedException e) {
            return new Oportunidad(id, idOrganizacion, titulo, descripcion, categoria, ubicacion, requisitos, estado);
        }
    }
}
