/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package microserviciooportunidades.persistencia;

import microserviciooportunidades.modelo.Oportunidad;
import microserviciooportunidades.singleton.ConexionPostgre;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author isaac
 */
public class OportunidadDaoPostgre implements OportunidadDAO {

    private final ConexionPostgre conexion = ConexionPostgre.getInstance();

    @Override
    public boolean insertar(Oportunidad oportunidad) throws Exception {
        String sql = "INSERT INTO oportunidades(id_organizacion, titulo, descripcion, categoria, ubicacion, requisitos, estado, created_at) VALUES(?,?,?,?,?,?,?,?)";
        try (Connection conn = conexion.getConnection(); PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setObject(1, oportunidad.getIdOrganizacion());
            ps.setString(2, oportunidad.getTitulo());
            ps.setString(3, oportunidad.getDescripcion());
            ps.setString(4, oportunidad.getCategoria());
            ps.setString(5, oportunidad.getUbicacion());
            ps.setString(6, oportunidad.getRequisitos());
            ps.setBoolean(7, oportunidad.getEstado() == null ? true : oportunidad.getEstado());
            ps.setTimestamp(8, new Timestamp(System.currentTimeMillis()));
            int r = ps.executeUpdate();
            if (r > 0) {
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        oportunidad.setId(rs.getInt(1));
                    }
                }
                return true;
            }
            return false;
        }
    }

    @Override
    public Optional<Oportunidad> consultarPorId(Integer id) throws Exception {
        String sql = "SELECT id, id_organizacion, titulo, descripcion, categoria, ubicacion, requisitos, estado FROM oportunidades WHERE id = ?";
        try (Connection conn = conexion.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Oportunidad o = new Oportunidad();
                    o.setId(rs.getInt("id"));
                    o.setIdOrganizacion((Integer) rs.getObject("id_organizacion"));
                    o.setTitulo(rs.getString("titulo"));
                    o.setDescripcion(rs.getString("descripcion"));
                    o.setCategoria(rs.getString("categoria"));
                    o.setUbicacion(rs.getString("ubicacion"));
                    o.setRequisitos(rs.getString("requisitos"));
                    o.setEstado(rs.getBoolean("estado"));
                    return Optional.of(o);
                }
                return Optional.empty();
            }
        }
    }

    @Override
    public boolean actualizar(Oportunidad oportunidad) throws Exception {
        String sql = "UPDATE oportunidades SET titulo=?, descripcion=?, categoria=?, ubicacion=?, requisitos=?, estado=? WHERE id=?";
        try (Connection conn = conexion.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, oportunidad.getTitulo());
            ps.setString(2, oportunidad.getDescripcion());
            ps.setString(3, oportunidad.getCategoria());
            ps.setString(4, oportunidad.getUbicacion());
            ps.setString(5, oportunidad.getRequisitos());
            ps.setBoolean(6, oportunidad.getEstado());
            ps.setInt(7, oportunidad.getId());
            int r = ps.executeUpdate();
            return r > 0;
        }
    }

    @Override
    public boolean eliminar(Integer id) throws Exception {
        String sql = "DELETE FROM oportunidades WHERE id = ?";
        try (Connection conn = conexion.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            int r = ps.executeUpdate();
            return r > 0;
        }
    }

    @Override
    public List<Oportunidad> listarTodos() throws Exception {
        String sql = "SELECT id, id_organizacion, titulo, descripcion, categoria, ubicacion, requisitos, estado FROM oportunidades ORDER BY created_at DESC";
        List<Oportunidad> lista = new ArrayList<>();
        try (Connection conn = conexion.getConnection(); PreparedStatement ps = conn.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Oportunidad o = new Oportunidad();
                o.setId(rs.getInt("id"));
                o.setIdOrganizacion((Integer) rs.getObject("id_organizacion"));
                o.setTitulo(rs.getString("titulo"));
                o.setDescripcion(rs.getString("descripcion"));
                o.setCategoria(rs.getString("categoria"));
                o.setUbicacion(rs.getString("ubicacion"));
                o.setRequisitos(rs.getString("requisitos"));
                o.setEstado(rs.getBoolean("estado"));
                lista.add(o);
            }
        }
        return lista;
    }

    @Override
    public List<Oportunidad> listarPorOrganizacion(Integer idOrganizacion) throws Exception {
        String sql = "SELECT id, id_organizacion, titulo, descripcion, categoria, ubicacion, requisitos, estado FROM oportunidades WHERE id_organizacion = ? ORDER BY created_at DESC";
        List<Oportunidad> lista = new ArrayList<>();
        try (Connection conn = conexion.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setObject(1, idOrganizacion);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Oportunidad o = new Oportunidad();
                    o.setId(rs.getInt("id"));
                    o.setIdOrganizacion((Integer) rs.getObject("id_organizacion"));
                    o.setTitulo(rs.getString("titulo"));
                    o.setDescripcion(rs.getString("descripcion"));
                    o.setCategoria(rs.getString("categoria"));
                    o.setUbicacion(rs.getString("ubicacion"));
                    o.setRequisitos(rs.getString("requisitos"));
                    o.setEstado(rs.getBoolean("estado"));
                    lista.add(o);
                }
            }
        }
        return lista;
    }
}
