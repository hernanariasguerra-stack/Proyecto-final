/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package microserviciooportunidades.servicio;

import microserviciooportunidades.dto.OportunidadDTO;
import microserviciooportunidades.persistencia.OportunidadDaoPostgre;
import microserviciooportunidades.persistencia.OportunidadDAO;
import microserviciooportunidades.modelo.Oportunidad;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author isaac
 */
public class OportunidadServicio {

    private final OportunidadDAO dao;

    public OportunidadServicio() {
        this.dao = new OportunidadDaoPostgre();
    }

    public boolean crearOportunidad(OportunidadDTO dto) throws Exception {
        Oportunidad o = new Oportunidad();
        o.setIdOrganizacion(dto.getIdOrganizacion());
        o.setTitulo(dto.getTitulo());
        o.setDescripcion(dto.getDescripcion());
        o.setCategoria(dto.getCategoria());
        o.setUbicacion(dto.getUbicacion());
        o.setRequisitos(dto.getRequisitos());
        o.setEstado(true);
        return dao.insertar(o);
    }

    public Optional<Oportunidad> obtenerPorId(Integer id) throws Exception {
        return dao.consultarPorId(id);
    }

    public List<Oportunidad> listarTodas() throws Exception {
        return dao.listarTodos();
    }

    public List<Oportunidad> listarPorOrganizacion(Integer idOrg) throws Exception {
        return dao.listarPorOrganizacion(idOrg);
    }

    public boolean actualizar(Oportunidad o) throws Exception {
        return dao.actualizar(o);
    }

    public boolean eliminar(Integer id) throws Exception {
        return dao.eliminar(id);
    }
}
