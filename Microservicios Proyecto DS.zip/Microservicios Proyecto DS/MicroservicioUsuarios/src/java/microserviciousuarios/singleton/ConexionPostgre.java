/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package microserviciousuarios.singleton;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author isaac
 */
public class ConexionPostgre {

    private static ConexionPostgre instance;
    private final String URL = "jdbc:postgresql://localhost:5432/sgvc_db_microusuario";
    private final String USER = "postgres";
    private final String PASS = "123456";

    private ConexionPostgre() {
    }

    public static synchronized ConexionPostgre getInstance() {
        if (instance == null) {
            instance = new ConexionPostgre();
        }
        return instance;
    }

    public Connection getConnection() throws SQLException {
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("Driver no encontrado", e);
        }
        return DriverManager.getConnection(URL, USER, PASS);
    }
}
