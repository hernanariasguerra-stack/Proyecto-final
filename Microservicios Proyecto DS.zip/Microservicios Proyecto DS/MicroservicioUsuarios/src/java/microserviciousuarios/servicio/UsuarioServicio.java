/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package microserviciousuarios.servicio;

import microserviciousuarios.dto.UsuarioDTO;
import microserviciousuarios.persistencia.UsuarioDaoPostgre;
import microserviciousuarios.persistencia.UsuarioDAO;
import microserviciousuarios.modelo.Usuario;
import java.util.Optional;
import java.util.List;
import java.security.MessageDigest;
import java.math.BigInteger;

/**
 *
 * @author isaac
 */
public class UsuarioServicio {

    private final UsuarioDAO usuarioDAO;

    public UsuarioServicio() {
        this.usuarioDAO = new UsuarioDaoPostgre();
    }

    public boolean registrarUsuario(UsuarioDTO dto) throws Exception {
        Optional<Usuario> existente = usuarioDAO.consultarPorCorreo(dto.getCorreo());
        if (existente.isPresent()) {
            return false;
        }
        Usuario u = new Usuario();
        u.setNombre(dto.getNombre());
        u.setCorreo(dto.getCorreo());
        u.setPasswordHash(hash(dto.getPassword()));
        u.setRol(dto.getRol() == null ? "VOLUNTARIO" : dto.getRol());
        u.setEstado(true);
        return usuarioDAO.insertar(u);
    }

    public Optional<Usuario> autenticar(String correo, String password) throws Exception {
        Optional<Usuario> uOpt = usuarioDAO.consultarPorCorreo(correo);
        if (!uOpt.isPresent()) {
            return Optional.empty();
        }
        Usuario u = uOpt.get();
        String h = hash(password);
        if (h.equals(u.getPasswordHash())) {
            return Optional.of(u);
        }
        return Optional.empty();
    }

    public Optional<Usuario> obtenerPorId(Integer id) throws Exception {
        List<Usuario> todos = usuarioDAO.listarTodos();
        for (Usuario u : todos) {
            if (u.getId().equals(id)) {
                return Optional.of(u);
            }
        }
        return Optional.empty();
    }

    public List<Usuario> listarTodos() throws Exception {
        return usuarioDAO.listarTodos();
    }

    public boolean actualizar(Usuario usuario) throws Exception {
        return usuarioDAO.actualizar(usuario);
    }

    public boolean eliminar(Integer id) throws Exception {
        return usuarioDAO.eliminar(id);
    }

    private String hash(String input) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] digest = md.digest(input.getBytes("UTF-8"));
        BigInteger number = new BigInteger(1, digest);
        StringBuilder hexString = new StringBuilder(number.toString(16));
        while (hexString.length() < 64) {
            hexString.insert(0, '0');
        }
        return hexString.toString();
    }

    public String hashParaActualizacion(String input) throws Exception {
        return hash(input);
    }
}
