/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package microserviciousuarios.presentacion;

import microserviciousuarios.dto.UsuarioDTO;
import microserviciousuarios.servicio.UsuarioServicio;
import microserviciousuarios.modelo.Usuario;
import java.io.IOException;
import java.util.List;
import java.util.Optional;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author isaac
 */
@WebServlet(name = "UsuarioControl", urlPatterns = {"/usuario"})
public class UsuarioControl extends HttpServlet {

    private UsuarioServicio servicio;

    @Override
    public void init() throws ServletException {
        super.init();
        servicio = new UsuarioServicio();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        try {
            if ("logout".equalsIgnoreCase(action)) {
                HttpSession s = request.getSession(false);
                if (s != null) {
                    s.invalidate();
                }
                response.sendRedirect("index.jsp");
                return;
            } else if ("list".equalsIgnoreCase(action)) {
                List<Usuario> lista = servicio.listarTodos();
                request.setAttribute("usuarios", lista);
                request.getRequestDispatcher("listarUsuarios.jsp").forward(request, response);
                return;
            } else if ("editForm".equalsIgnoreCase(action)) {
                String idStr = request.getParameter("id");
                if (idStr != null && !idStr.isEmpty()) {
                    Integer id = Integer.parseInt(idStr);
                    Optional<Usuario> uOpt = servicio.obtenerPorId(id);
                    if (uOpt.isPresent()) {
                        request.setAttribute("usuarioEdit", uOpt.get());
                        request.getRequestDispatcher("editarUsuario.jsp").forward(request, response);
                        return;
                    }
                }
                response.sendRedirect("usuario?action=list");
                return;
            } else if ("delete".equalsIgnoreCase(action)) {
                String idStr = request.getParameter("id");
                if (idStr != null && !idStr.isEmpty()) {
                    Integer id = Integer.parseInt(idStr);
                    servicio.eliminar(id);
                }
                response.sendRedirect("usuario?action=list");
                return;
            }
        } catch (Exception e) {
            response.sendRedirect("error.jsp");
            return;
        }
        response.sendRedirect("index.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        try {
            if ("register".equalsIgnoreCase(action)) {
                String nombre = request.getParameter("nombre");
                String correo = request.getParameter("correo");
                String password = request.getParameter("password");
                String rol = request.getParameter("rol");
                UsuarioDTO dto = new UsuarioDTO(nombre, correo, password, rol);
                boolean ok = servicio.registrarUsuario(dto);
                if (ok) {
                    response.sendRedirect("login.jsp?msg=registered");
                } else {
                    response.sendRedirect("registro.jsp?error=exists");
                }
                return;
            } else if ("login".equalsIgnoreCase(action)) {
                String correo = request.getParameter("correo");
                String password = request.getParameter("password");
                Optional<Usuario> uOpt = servicio.autenticar(correo, password);
                if (uOpt.isPresent()) {
                    Usuario u = uOpt.get();
                    HttpSession s = request.getSession(true);
                    s.setAttribute("usuario", u);
                    if ("ORGANIZACION".equalsIgnoreCase(u.getRol())) {
                        response.sendRedirect("menu.jsp?role=organizacion");
                    } else if ("VOLUNTARIO".equalsIgnoreCase(u.getRol())) {
                        response.sendRedirect("menu.jsp?role=voluntario");
                    } else {
                        response.sendRedirect("menu.jsp?role=admin");
                    }
                } else {
                    response.sendRedirect("login.jsp?error=cred");
                }
                return;
            } else if ("update".equalsIgnoreCase(action)) {
                String idStr = request.getParameter("id");
                if (idStr != null && !idStr.isEmpty()) {
                    Integer id = Integer.parseInt(idStr);
                    Optional<Usuario> uOpt = servicio.obtenerPorId(id);
                    if (uOpt.isPresent()) {
                        Usuario u = uOpt.get();
                        String nombre = request.getParameter("nombre");
                        String rol = request.getParameter("rol");
                        String estadoStr = request.getParameter("estado");
                        String nuevaPassword = request.getParameter("password");
                        u.setNombre(nombre);
                        u.setRol(rol);
                        u.setEstado("on".equalsIgnoreCase(estadoStr) || "true".equalsIgnoreCase(estadoStr));
                        if (nuevaPassword != null && !nuevaPassword.trim().isEmpty()) {
                            u.setPasswordHash(servicio.hashParaActualizacion(nuevaPassword));
                        }
                        servicio.actualizar(u);
                    }
                }
                response.sendRedirect("usuario?action=list");
                return;
            }
        } catch (Exception e) {
            response.sendRedirect("error.jsp");
            return;
        }
        response.sendRedirect("index.jsp");
    }
}
