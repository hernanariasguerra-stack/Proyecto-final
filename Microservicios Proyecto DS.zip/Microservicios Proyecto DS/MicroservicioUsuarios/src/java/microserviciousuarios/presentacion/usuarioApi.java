/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package microserviciousuarios.presentacion;

import microserviciousuarios.servicio.UsuarioServicio;
import microserviciousuarios.modelo.Usuario;
import java.io.IOException;
import java.util.Optional;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

/**
 *
 * @author isaac
 */
@WebServlet(name = "UsuarioApi", urlPatterns = {"/usuarioApi"})
public class UsuarioApi extends HttpServlet {

    private UsuarioServicio servicio;

    @Override
    public void init() throws ServletException {
        super.init();
        servicio = new UsuarioServicio();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        response.setContentType("application/json");
        try {
            if ("existsById".equalsIgnoreCase(action)) {
                String idStr = request.getParameter("id");
                boolean exists = false;
                if (idStr != null && !idStr.isEmpty()) {
                    Integer id = Integer.parseInt(idStr);
                    Optional<Usuario> u = servicio.obtenerPorId(id);
                    exists = u.isPresent();
                }
                response.getWriter().write("{\"exists\":" + exists + "}");
                return;
            }
        } catch (Exception e) {
            response.getWriter().write("{\"exists\":false}");
            return;
        }
        response.getWriter().write("{\"exists\":false}");
    }
}
