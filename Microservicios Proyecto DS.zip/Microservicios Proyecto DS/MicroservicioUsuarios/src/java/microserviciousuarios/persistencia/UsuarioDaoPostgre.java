/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package microserviciousuarios.persistencia;

import microserviciousuarios.modelo.Usuario;
import microserviciousuarios.singleton.ConexionPostgre;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author isaac
 */
public class UsuarioDaoPostgre implements UsuarioDAO {

    private final ConexionPostgre conexion = ConexionPostgre.getInstance();

    @Override
    public boolean insertar(Usuario usuario) throws Exception {
        String sql = "INSERT INTO usuarios(nombre, correo, password_hash, rol, estado, created_at) VALUES(?,?,?,?,?,?)";
        try (Connection conn = conexion.getConnection(); PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, usuario.getNombre());
            ps.setString(2, usuario.getCorreo());
            ps.setString(3, usuario.getPasswordHash());
            ps.setString(4, usuario.getRol());
            ps.setBoolean(5, usuario.getEstado() == null ? true : usuario.getEstado());
            ps.setTimestamp(6, new Timestamp(System.currentTimeMillis()));
            int r = ps.executeUpdate();
            if (r > 0) {
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        usuario.setId(rs.getInt(1));
                    }
                }
                return true;
            }
            return false;
        }
    }

    @Override
    public Optional<Usuario> consultarPorCorreo(String correo) throws Exception {
        String sql = "SELECT id, nombre, correo, password_hash, rol, estado FROM usuarios WHERE correo = ?";
        try (Connection conn = conexion.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, correo);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Usuario u = new Usuario();
                    u.setId(rs.getInt("id"));
                    u.setNombre(rs.getString("nombre"));
                    u.setCorreo(rs.getString("correo"));
                    u.setPasswordHash(rs.getString("password_hash"));
                    u.setRol(rs.getString("rol"));
                    u.setEstado(rs.getBoolean("estado"));
                    return Optional.of(u);
                }
                return Optional.empty();
            }
        }
    }

    @Override
    public boolean actualizar(Usuario usuario) throws Exception {
        String sql = "UPDATE usuarios SET nombre=?, password_hash=?, rol=?, estado=? WHERE correo=?";
        try (Connection conn = conexion.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, usuario.getNombre());
            ps.setString(2, usuario.getPasswordHash());
            ps.setString(3, usuario.getRol());
            ps.setBoolean(4, usuario.getEstado());
            ps.setString(5, usuario.getCorreo());
            int r = ps.executeUpdate();
            return r > 0;
        }
    }

    @Override
    public boolean eliminar(Integer id) throws Exception {
        String sql = "DELETE FROM usuarios WHERE id = ?";
        try (Connection conn = conexion.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            int r = ps.executeUpdate();
            return r > 0;
        }
    }

    @Override
    public List<Usuario> listarTodos() throws Exception {
        String sql = "SELECT id, nombre, correo, password_hash, rol, estado FROM usuarios";
        List<Usuario> lista = new ArrayList<>();
        try (Connection conn = conexion.getConnection(); PreparedStatement ps = conn.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Usuario u = new Usuario();
                u.setId(rs.getInt("id"));
                u.setNombre(rs.getString("nombre"));
                u.setCorreo(rs.getString("correo"));
                u.setPasswordHash(rs.getString("password_hash"));
                u.setRol(rs.getString("rol"));
                u.setEstado(rs.getBoolean("estado"));
                lista.add(u);
            }
        }
        return lista;
    }
}
